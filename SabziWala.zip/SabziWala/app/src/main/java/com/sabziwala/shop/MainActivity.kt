package com.sabziwala.shop


import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import com.google.android.material.bottomnavigation.BottomNavigationItemView
import com.google.android.material.bottomnavigation.BottomNavigationMenuView
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.lang.reflect.Array.setBoolean


class MainActivity : AppCompatActivity() {
    private val REQUEST_CODE = 100
    lateinit var toolbar: Toolbar
    lateinit var drawerLayout: RelativeLayout
    lateinit var navigationView: BottomNavigationView
    lateinit var webView: WebView
    lateinit var progressBar: ProgressBar
    lateinit var loadingView:RelativeLayout
    lateinit var voiceText:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toolbar = findViewById(R.id.toolbar)
        drawerLayout = findViewById(R.id.drawer_layout)
        webView = findViewById(R.id.WebView)
        progressBar = findViewById(R.id.ProgressBar)
        loadingView=findViewById(R.id.LoadingView)
        navigationView = findViewById(R.id.navigation_view)
        setUpToolbar("Home")
        navigationView.setOnNavigationItemSelectedListener { item: MenuItem ->
            when (item?.itemId) {
                R.id.home -> {
                    loadingView.visibility=View.VISIBLE
                    setUpToolbar("Home")
                    loadPage("https://www.sabziwala.shop")
                }
                R.id.products -> {
                    loadingView.visibility=View.VISIBLE
                    setUpToolbar("Shop")
                    loadPage("https://www.sabziwala.shop/shop-1")
                }
                R.id.myAccount -> {
                    loadingView.visibility=View.VISIBLE
                    setUpToolbar("My Account")
                    loadPage("https://www.sabziwala.shop/account/my-account")
                }
                R.id.contact -> {
                    loadingView.visibility=View.VISIBLE
                    setUpToolbar("Contact Us")
                    loadPage("https://www.sabziwala.shop/contact-us-feedback")
                }
                R.id.voice->{
                    promptSpeechInput()
                }
            }
            return@setOnNavigationItemSelectedListener true
        }

        loadPage("https://www.sabziwala.shop")
    }

    private fun promptSpeechInput() {
        val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        try {
            startActivityForResult(intent, REQUEST_CODE)
        } catch (a: ActivityNotFoundException) {
        }
    }
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_CODE -> {
                if (resultCode == Activity.RESULT_OK && null != data) {
                    val result =
                        data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    voiceText=result[0]
                }

            }
        }
        loadPage("https://www.sabziwala.shop/search-results/q-$voiceText")
    }


    fun setUpToolbar(title: String) {
        setSupportActionBar(toolbar)
        supportActionBar?.title = title

    }
    override  fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.share_menu,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id=item.itemId
        if(id==R.id.action_share){
            val intent=Intent(android.content.Intent.ACTION_SEND)
            intent.setType("text/plain")
            intent.putExtra(Intent.EXTRA_TEXT,"https://play.google.com/store/apps/details?id=com.sabziwala.shop")
            startActivity(Intent.createChooser(intent,"Share"))
        }
        return super.onOptionsItemSelected(item)
    }


    fun loadPage(url: String) {
        if (ConnectionManager().checkConnectivity(this@MainActivity)) {
            webView.webViewClient = WebViewClient()
            webView.settings.loadsImagesAutomatically = true
            webView.settings.setSupportZoom(true)
            webView.settings.javaScriptEnabled = true
            webView.settings.setSupportMultipleWindows(true)
            webView.settings.useWideViewPort = true
            webView.settings.loadWithOverviewMode = false
            webView.settings.javaScriptCanOpenWindowsAutomatically = true
            webView.settings.setRenderPriority(WebSettings.RenderPriority.HIGH)
            webView.settings.domStorageEnabled = true
            webView.settings.layoutAlgorithm = WebSettings.LayoutAlgorithm.NARROW_COLUMNS
            webView.settings.useWideViewPort = true
            webView.settings.savePassword = true
            webView.settings.saveFormData = true
            webView.settings.setEnableSmoothTransition(true)
            webView.loadUrl(url)
            webView.webViewClient=object:WebViewClient(){
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                    if(url.contains("tel:")){
                        val intent=Intent(Intent.ACTION_DIAL)
                        intent.setData(Uri.parse(url))
                        startActivity(intent)
                    }
                    else if(url.contains("mailto:")){
                        val intent=Intent(Intent.ACTION_SEND)
                        val mail=url.substring(7)
                        var email=arrayOf(mail)
                        intent.putExtra(Intent.EXTRA_EMAIL,email)
                        intent.setType("text/html")
                        intent.setPackage("com.google.android.gm")
                        startActivity(intent)
                    }
                    else{
                    view.loadUrl(url)
                    loadingView.visibility=View.VISIBLE}
                    return true
                }

                override fun onPageCommitVisible(view: WebView?, url: String?) {
                    super.onPageCommitVisible(view, url)
                    loadingView.visibility=View.GONE
                }

            }
        } else {
            val dialog = AlertDialog.Builder(this@MainActivity)
            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection not Found")
            dialog.setPositiveButton("Retry") { text, listener ->
                loadPage(url)
            }
            dialog.setNegativeButton("Cancel") { text, listener ->
                ActivityCompat.finishAffinity(this@MainActivity)
            }
            dialog.create()
            dialog.show()
        }

    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (keyCode) {
                KeyEvent.KEYCODE_BACK -> {
                    if (webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        finish()
                    }
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)


    }


}



